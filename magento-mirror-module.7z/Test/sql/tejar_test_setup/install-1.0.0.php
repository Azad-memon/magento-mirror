<?php
$installer = $this;
$installer->startSetup();

$tableName = $installer->getTable('fraud_emails');

$table = $installer->getConnection()
    ->newTable($tableName)
    ->addColumn('entity_id', Varien_Db_Ddl_Table::TYPE_INTEGER, null, array(
        'identity' => true,
        'nullable' => false,
        'primary'  => true,
    ), 'ID')
    ->addColumn('email', Varien_Db_Ddl_Table::TYPE_TEXT, 255, array(
        'nullable' => false,
    ), 'Email');

$installer->getConnection()->createTable($table);

$installer->endSetup();
