<?php
class Tejar_Test_Adminhtml_TestController extends Mage_Adminhtml_Controller_Action
{
//    public function indexAction()
//    {
//        $this->loadLayout();
//        $this->_setActiveMenu('catalog/test');
//        $block = $this->getLayout()->createBlock('test/adminhtml_test');
//        $block->setTemplate('tejar/test/test.phtml');
//        $this->_title($this->__('Test Page'));
//
//        $fraudEmails = Mage::getModel('tejar_test/fraudemail')->getCollection();
//        $increment=0;
//        foreach ($fraudEmails as $fraudEmail) {
//
//            $email[$increment]['id'] = $fraudEmail->entity_id;
//            $email[$increment++]['email'] = $fraudEmail->email;
//
//        }
//
//
//
//        $data = new Varien_Object();
//
//        $block->setData('data', $email);
//        $this->_addContent($block);
//        $this->renderLayout();
//    }
    public function indexAction()
    {
        $this->loadLayout();
        $this->_setActiveMenu('catalog/test');
        $this->_title($this->__('Test Page'));
        $gridContainer = $this->getLayout()->createBlock('test/adminhtml_test');
        $gridContainer->setTemplate('tejar/test/test.phtml');
        $this->_addContent($gridContainer);
        $this->renderLayout();
    }

    public function newAction()
    {
        $this->loadLayout();
        $this->_setActiveMenu('catalog/test');
        $this->_title($this->__('Add New Record'));
        $block = $this->getLayout()->createBlock('test/adminhtml_addnew');
        $block->setTemplate('tejar/test/add_new.phtml');
        $this->_addContent($block);
        $this->renderLayout();

    }

    public function saveAction()
    {
        if ($data = $this->getRequest()->getPost()) {
            try {
                // Validate email field
                if (!isset($data['email']) || empty($data['email'])) {
                    throw new Exception('Email field is required.');
                }

                // Check if the email already exists
                $existingEmail = Mage::getModel('tejar_test/fraudemail')->load($data['email'], 'email');
                if ($existingEmail->getId()) {
                    throw new Exception('Email already exists.');
                }

                // Create new fraud email object
                $fraudEmail = Mage::getModel('tejar_test/fraudemail');
//                $fraudEmail->setData($data);
                $fraudEmail->email= $data['email'];
                // Save the new record
                $fraudEmail->save();

                Mage::getSingleton('adminhtml/session')->addSuccess('Record has been saved successfully.');
                $this->_redirect('*/*/index');
                return;
            } catch (Exception $e) {
                Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
                $this->_redirectReferer();
                return;
            }
        }

        Mage::getSingleton('adminhtml/session')->addError('Unable to save record. Please try again.');
        $this->_redirectReferer();
    }

    public function deleteAction()
    {
        $id = $this->getRequest()->getParam('id');
        if ($id) {
            try {
                $model = Mage::getModel('tejar_test/fraudemail');
                $model->load($id)->delete();
                Mage::getSingleton('adminhtml/session')->addSuccess(
                    Mage::helper('adminhtml')->__('Item was successfully deleted')
                );
            } catch (Exception $e) {
                Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
            }
        }
        $this->_redirect('*/*/');
    }



}
