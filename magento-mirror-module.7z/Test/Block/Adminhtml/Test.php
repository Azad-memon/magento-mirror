<?php
class Tejar_Test_Block_Adminhtml_Test extends Mage_Core_Block_Template
{
    public function __construct()
    {
        parent::__construct();
    }

    public function setData($key, $value = null)
    {
        if (is_array($key)) {
            $this->_data = array_merge($this->_data, $key);
        } else {
            $this->_data[$key] = $value;
        }
        return $this;
    }

    public function getData($key = '', $index = null)
    {
        if ('' === $key) {
            return $this->_data;
        }

        if (isset($this->_data[$key])) {
            if (is_null($index)) {
                return $this->_data[$key];
            } elseif (is_array($this->_data[$key]) || $this->_data[$key] instanceof \ArrayAccess) {
                return isset($this->_data[$key][$index]) ? $this->_data[$key][$index] : null;
            }
        }

        return null;
    }
}
?>
