<?php
// app/code/local/Tejar/Test/Block/Adminhtml/Fraudemail.php
class Tejar_Test_Block_Adminhtml_Fraudemail extends Mage_Adminhtml_Block_Widget_Grid_Container
{
    public function __construct()
    {
        $this->_controller = 'adminhtml_fraudemail';
        $this->_blockGroup = 'test';
        $this->_headerText = Mage::helper('test')->__('Fraud Email');
        $this->_addButtonLabel = Mage::helper('test')->__('Add Fraud Email');
        $this->_addButton('add_new', array(
            'label'   => Mage::helper('test')->__('Add New Fraud Email'),
            'onclick' => "setLocation('{$this->getUrl('*/*/new')}')",
            'class'   => 'add'
        ));

        parent::__construct();
        $this->_removeButton('add');
    }

    protected function _prepareLayout()
    {

        $gridBlock = $this->getLayout()->createBlock('test/adminhtml_fraudemail_grid');

        $this->setChild('grid', $gridBlock);
        return parent::_prepareLayout();
    }
}

?>