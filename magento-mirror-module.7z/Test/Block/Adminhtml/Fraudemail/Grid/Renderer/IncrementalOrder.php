<?php
class Tejar_Test_Block_Adminhtml_Fraudemail_Grid_Renderer_IncrementalOrder extends Mage_Adminhtml_Block_Widget_Grid_Column_Renderer_Abstract
{
    protected static $_count = 0;

    public function render(Varien_Object $row)
    {
        return ++$this::$_count;
    }
}
?>
