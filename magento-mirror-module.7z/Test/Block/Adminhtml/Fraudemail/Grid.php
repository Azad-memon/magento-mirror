<?php

class Tejar_Test_Block_Adminhtml_Fraudemail_Grid extends Mage_Adminhtml_Block_Widget_Grid
{
    public function __construct()
    {
        parent::__construct();
        $this->setId('fraudemailGrid');
        $this->setDefaultSort('entity_id');
        $this->setDefaultDir('DESC');
        $this->setSaveParametersInSession(true);

    }

    protected function _prepareCollection()
    {
        $collection = Mage::getModel('tejar_test/fraudemail')->getCollection();
        $this->setCollection($collection);
        return parent::_prepareCollection();
    }

    protected function _prepareColumns()
    {
        $this->addColumn('incremental_order', array(
            'header'    => Mage::helper('test')->__('Incremental Order'),
            'align'     =>'right',
            'width'     => '50px',
            'renderer'  => 'Tejar_Test_Block_Adminhtml_Fraudemail_Grid_Renderer_IncrementalOrder',
        ));

        $this->addColumn('email', array(
            'header'    => Mage::helper('test')->__('Email'),
            'align'     =>'left',
            'index'     => 'email',
        ));

        // Add the third column for deleting records
        $this->addColumn('action', array(
            'header'    => Mage::helper('test')->__('Action'),
            'width'     => '100',
            'type'      => 'action',
            'getter'    => 'getId',
            'actions'   => array(
                array(
                    'caption'   => Mage::helper('test')->__('Delete'),
                    'url'       => array('base' => '*/*/delete'),
                    'field'     => 'id',
                    'confirm'   => Mage::helper('test')->__('Are you sure you want to delete this item?')
                ),
            ),

            'filter'    => false,
            'sortable'  => false,
            'index'     => 'stores',
            'is_system' => true,
        ));


        return parent::_prepareColumns();
    }

}
?>