<?php
class Tejar_Test_Block_Adminhtml_Addnew extends Mage_Adminhtml_Block_Widget_Form_Container
{
    public function __construct()
    {
        parent::__construct();
        $this->_blockGroup = 'tejar_test';
        $this->_controller = 'adminhtml_addnew';
        $this->_mode = 'new'; // Set mode to edit
        $this->_updateButton('save', 'label', Mage::helper('test')->__('Save'));
        $this->_updateButton('delete', 'label', Mage::helper('test')->__('Delete'));
    }

    public function getHeaderText()
    {
        return Mage::helper('test')->__('Add New Fraud Email');
    }
}
