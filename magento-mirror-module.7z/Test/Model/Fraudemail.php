<?php
class Tejar_Test_Model_Fraudemail extends Mage_Core_Model_Abstract
{
    protected function _construct()
    {
        parent::_construct();
        $this->_init('tejar_test/fraudemail');
    }
}
